// import React, { useRef } from "react";
// import { Canvas, extend, useFrame } from "@react-three/fiber";
// import { OrbitControls } from "@react-three/drei";
// import { TextGeometry } from "three/examples/jsm/geometries/TextGeometry";
// import { FontLoader } from "three/examples/jsm/loaders/FontLoader";
// import * as THREE from "three";
// import fontData from "three/examples/fonts/helvetiker_regular.typeface.json";

// extend({ TextGeometry });

// const Cube = ({ position, size, color }) => {
//   const ref = useRef();

//   useFrame((state, delta) => {
//     if (ref.current) {
//       ref.current.rotation.x += delta;
//       ref.current.rotation.y += delta * 2.0;
//       ref.current.position.z = Math.sin(state.clock.elapsedTime) * 2;
//     }
//   });

//   return (
//     <mesh position={position} ref={ref}>
//       <boxGeometry args={size} />
//       <meshStandardMaterial color={color} />
//     </mesh>
//   );
// };

// const Sphere = ({ position, size, color }) => {
//   const ref = useRef();

//   useFrame((state, delta) => {
//     if (ref.current) {
//       ref.current.rotation.x += delta;
//       ref.current.rotation.y += delta * 2.0;
//       ref.current.position.z = Math.sin(state.clock.elapsedTime) * 2;
//     }
//   });

//   return (
//     <mesh position={position} ref={ref}>
//       <sphereGeometry args={size} />
//       <meshStandardMaterial color={color} />
//     </mesh>
//   );
// };

// const Torous = ({ position, size, color }) => {
//   const ref = useRef();

//   useFrame((state, delta) => {
//     if (ref.current) {
//       ref.current.rotation.x += delta;
//       ref.current.rotation.y += delta * 2.0;
//       ref.current.position.z = Math.sin(state.clock.elapsedTime) * 2;
//     }
//   });

//   return (
//     <mesh position={position} ref={ref}>
//       <torusGeometry args={size} />
//       <meshStandardMaterial color={color} />
//     </mesh>
//   );
// };

// const TorousKnot = ({ position, size, color }) => {
//   return (
//     <mesh position={position}>
//       <torusKnotGeometry args={size} />
//       <meshStandardMaterial color={color} />
//     </mesh>
//   );
// };

// export default function App() {
//   const font = new FontLoader().parse(fontData);

//   return (
//     <div style={{ backgroundColor: "black" }}>
//       <Canvas>
//         <directionalLight position={[0, 0, 2]} intensity={0.8} />
//         <ambientLight intensity={0.2} />
//         <OrbitControls enableZoom={true} />
//         <group position={[0, 0, 0]}>
//           <Sphere position={[0, 0, 0]} size={[1, 32, 32]} color="blue" />
//           <Torous position={[1, 0, 0]} size={[1, 32, 32]} color="red" />
//           <TorousKnot position={[2, 0, 0]} size={[1, 32, 32]} color="white" />
//         </group>
//         <mesh position={[-10, 0, 0]}>
//           <textGeometry args={["ALTUS", { font, size: 5, height: 1 }]} />
//           <meshBasicMaterial color="white" wireframe />
//         </mesh>
//       </Canvas>
//     </div>
//   );
// }

///*-----------------------------------------------------------------Code For Infinite LOGO Transparent Tube like Structure -*-------------------------

// import React, { useRef, useMemo } from "react";
// import { Canvas, useFrame } from "@react-three/fiber";
// import { OrbitControls } from "@react-three/drei";
// import * as THREE from "three";

// class InfinityCurve extends THREE.Curve {
//   constructor(scale = 1) {
//     super();
//     this.scale = scale;
//   }

//   getPoint(t) {
//     if (t < 0 || t > 1) return new THREE.Vector3(0, 0, 0);

//     const angle = t * Math.PI * 2;
//     const x = Math.sin(angle) * this.scale;
//     const y = (Math.sin(2 * angle) * this.scale) / 2;
//     const z = 0;

//     return new THREE.Vector3(x, y, z);
//   }
// }

// class ErrorBoundary extends React.Component {
//   constructor(props) {
//     super(props);
//     this.state = { hasError: false };
//   }

//   static getDerivedStateFromError(error) {
//     return { hasError: true };
//   }

//   componentDidCatch(error, info) {
//     console.error("ErrorBoundary caught an error:", error, info);
//   }

//   render() {
//     if (this.state.hasError) {
//       return (
//         <h2>
//           Something went wrong with the InfinitySymbol. Please try again later.
//         </h2>
//       );
//     }
//     return this.props.children;
//   }
// }

// function InfinitySymbol() {
//   const ref = useRef();
//   const path = new InfinityCurve(2);
//   useFrame(() => {
//     if (ref.current) {
//       ref.current.rotation.x += 0.01;
//       ref.current.rotation.y += 0.01;
//     }
//   });

//   const tubeGeometry = useMemo(() => {
//     const path = new InfinityCurve(2);
//     return new THREE.TubeGeometry(path, 200, 0.3, 16, true);
//   }, []);

//   const points = [];
//   const linePath = new InfinityCurve(2);
//   for (let i = 0; i <= 100; i++) {
//     const t = i / 100;
//     points.push(linePath.getPoint(t));
//   }

//   const lineGeometry = new THREE.BufferGeometry().setFromPoints(points);
//   const lineMaterial = new THREE.LineBasicMaterial({ color: "red" });

//   const combinedGeometry = new THREE.BufferGeometry();

//   const tubePosition = tubeGeometry.attributes.position.array;
//   combinedGeometry.setAttribute(
//     "position",
//     new THREE.BufferAttribute(tubePosition, 3)
//   );

//   const linePosition = lineGeometry.attributes.position.array;

//   combinedGeometry.setAttribute(
//     "linePosition",
//     new THREE.BufferAttribute(linePosition, 3)
//   );

//   if (!tubeGeometry) {
//     console.error("TubeGeometry is null.");
//     return null;
//   }

//   const wireframeMaterial = new THREE.MeshBasicMaterial({
//     color: "white",
//     wireframe: true,
//   });

//   return (
//     <mesh ref={ref} geometry={combinedGeometry} material={wireframeMaterial} />
//   );
// }

// function App() {
//   return (
//     <ErrorBoundary>
//       <Canvas style={{ backgroundColor: "black", height: "100vh" }}>
//         <ambientLight />
//         <pointLight position={[10, 10, 10]} />
//         <InfinitySymbol />
//         <OrbitControls />
//       </Canvas>
//     </ErrorBoundary>
//   );
// }

// export default App;

// ----------------------------------------------------------------   Code for the SkyBlue tube logo  -------------------------------

// import React, { useRef, useMemo } from "react";
// import { Canvas, useFrame } from "@react-three/fiber";
// import { OrbitControls } from "@react-three/drei";
// import * as THREE from "three";

// class InfinityCurve extends THREE.Curve {
//   constructor(scale = 1) {
//     super();
//     this.scale = scale;
//   }

//   getPoint(t) {
//     if (t < 0 || t > 1) return new THREE.Vector3(0, 0, 0);

//     const angle = t * Math.PI * 2;
//     const x = Math.sin(angle) * this.scale;
//     const y = (Math.sin(2 * angle) * this.scale) / 2;
//     const z = 0;

//     return new THREE.Vector3(x, y, z);
//   }
// }

// class ErrorBoundary extends React.Component {
//   constructor(props) {
//     super(props);
//     this.state = { hasError: false };
//   }

//   static getDerivedStateFromError(error) {
//     return { hasError: true };
//   }

//   componentDidCatch(error, info) {
//     console.error("ErrorBoundary caught an error:", error, info);
//   }

//   render() {
//     if (this.state.hasError) {
//       return (
//         <h2>
//           Something went wrong with the InfinitySymbol. Please try again later.
//         </h2>
//       );
//     }
//     return this.props.children;
//   }
// }

// function InfinitySymbol() {
//   const ref = useRef();
//   const path = new InfinityCurve(2);

//   useFrame(() => {
//     if (ref.current) {
//       ref.current.rotation.x += 0.01;
//       ref.current.rotation.y += 0.01;
//     }
//   });

//   const tubeGeometry = useMemo(() => {
//     const path = new InfinityCurve(2);
//     return new THREE.TubeGeometry(path, 200, 0.3, 16, true);
//   }, []);

//   const tubeMaterial = new THREE.MeshStandardMaterial({
//     color: new THREE.Color("skyblue"),
//     metalness: 0.6,
//     roughness: 0.4,
//   });

//   if (!tubeGeometry) {
//     console.error("TubeGeometry is null.");
//     return null;
//   }

//   return <mesh ref={ref} geometry={tubeGeometry} material={tubeMaterial} />;
// }

// function App() {
//   return (
//     <ErrorBoundary>
//       <Canvas style={{ backgroundColor: "black", height: "100vh" }}>
//         <ambientLight intensity={0.5} />{" "}
//         <directionalLight
//           position={[0, 0, 2]}
//           intensity={2}
//           color={new THREE.Color("white")}
//           castShadow
//         />
//         <InfinitySymbol />
//         <OrbitControls />
//       </Canvas>
//     </ErrorBoundary>
//   );
// }

// export default App;

// ---------------------------------------------------------------------------------------------------------------------------------------------------


// import * as THREE from "three";
// import { Canvas } from "@react-three/fiber";
// import { useRef } from "react";
// import { OrbitControls } from "@react-three/drei";

// const InfiniteWavyRing = ({
//   innerRadius,
//   outerRadius,
//   waveHeight,
//   waveFrequency,
// }) => {
//   const meshRef = useRef();

//   // Create a RingGeometry
//   const geometry = new THREE.RingGeometry(innerRadius, outerRadius, 128, 1);

//   const position = geometry.attributes.position;

//   for (let i = 0; i < position.count; i++) {
//     const x = position.getX(i);
//     const y = position.getY(i);

//     // Apply wave deformation based on X and Y coordinates
//     const waveOffset = Math.sin((x + y) * waveFrequency) * waveHeight;

//     // Modify the Z-coordinate to create the wave effect
//     const z = waveOffset;

//     position.setZ(i, z);
//   }

//   // Mark position for update
//   position.needsUpdate = true;

//   return (
//     <mesh ref={meshRef} geometry={geometry}>
//       <meshStandardMaterial color="orange" side={THREE.DoubleSide} />
//     </mesh>
//   );
// };

// const Scene = () => {
//   return (
//     <Canvas camera={{ position: [0, 0, 10], fov: 60 }}>
//       {/* Lighting */}
//       <ambientLight intensity={0.5} />
//       <directionalLight position={[5, 5, 5]} intensity={1} />
//       <OrbitControls />
//       {/* Infinite Wavy Ring */}
//       <InfiniteWavyRing
//         innerRadius={1.5}
//         outerRadius={2}
//         waveHeight={0.5}
//         waveFrequency={2}
//       />
//     </Canvas>
//   );
// };

// export default Scene;




// -----------------------------------------------------------------------------------   noraml ring like structure

// import * as THREE from "three";
// import { Canvas } from "@react-three/fiber";
// import { useRef } from "react";
// import { OrbitControls } from "@react-three/drei";

// const InfiniteWavyRing = ({
//   innerRadius,
//   outerRadius,
//   waveHeight,
//   waveFrequency,
// }) => {
//   const meshRef = useRef();

//   // Create a RingGeometry
//   const geometry = new THREE.RingGeometry(innerRadius, outerRadius, 128, 1);

//   const position = geometry.attributes.position;

//   for (let i = 0; i < position.count; i++) {
//     const x = position.getX(i);
//     const y = position.getY(i);

//     // Smooth transition at the X boundary for opposite bending
//     const waveFactor = Math.sin((x + y) * waveFrequency);

//     // Smooth transition using a cosine function to blend the wave
//     const smoothTransition = Math.cos(
//       ((Math.abs(x) % (2 * Math.PI)) / (2 * Math.PI)) * Math.PI
//     );

//     // Calculate the wave offset using smooth transition
//     let waveOffset = waveFactor * waveHeight * smoothTransition;

//     // Modify the Z-coordinate to create the wave effect
//     const z = waveOffset;

//     position.setZ(i, z);
//   }

//   // Mark position for update
//   position.needsUpdate = true;

//   return (
//     <mesh ref={meshRef} geometry={geometry}>
//       <meshStandardMaterial color="orange" side={THREE.DoubleSide} />
//     </mesh>
//   );
// };

// const Scene = () => {
//   return (
//     <Canvas camera={{ position: [0, 0, 10], fov: 60 }}>
//       {/* Lighting */}
//       <ambientLight intensity={0.5} />
//       <directionalLight position={[5, 5, 5]} intensity={1} />
//       <OrbitControls />
//       {/* Infinite Wavy Ring */}
//       <InfiniteWavyRing
//         innerRadius={1.5}
//         outerRadius={2}
//         waveHeight={0.5}
//         waveFrequency={1}
//       />
//     </Canvas>
//   );
// };

// export default Scene;


// ---------------------------------------------------------------------------------------    AI RING 3D MODEL ----


// import * as THREE from "three";
// import { Canvas, useLoader } from "@react-three/fiber";
// import { useRef, useMemo } from "react";
// import { OrbitControls } from "@react-three/drei";

// // Custom function to create a circular path for TubeGeometry
// const createCircularPath = (radius) => {
//   const curve = new THREE.Curve();
//   curve.getPoint = (t) => {
//     const angle = t * 2 * Math.PI;
//     return new THREE.Vector3(
//       Math.cos(angle) * radius,
//       Math.sin(angle) * radius,
//       0
//     );
//   };
//   return curve;
// };

// const InfiniteWavyRing = ({
//   innerRadius,
//   outerRadius,
//   waveHeight,
//   waveFrequency,
//   logoTexture,
// }) => {
//   const meshRef = useRef();
//   const path = useMemo(
//     () => createCircularPath((innerRadius + outerRadius) / 2),
//     [innerRadius, outerRadius]
//   );
//   const tubeRadius = (outerRadius - innerRadius) / 2; // Inner thickness of the ring

//   // Create TubeGeometry based on the circular path
//   const geometry = new THREE.TubeGeometry(path, 128, tubeRadius, 32, true);
//   const position = geometry.attributes.position;

//   for (let i = 0; i < position.count; i++) {
//     const x = position.getX(i);
//     const y = position.getY(i);

//     const waveFactor = Math.sin((y + x) * waveFrequency);
//     const smoothTransition = Math.cos(
//       ((Math.abs(y) % (2 * Math.PI)) / (2 * Math.PI)) * Math.PI
//     );
//     const waveOffset = waveFactor * waveHeight * smoothTransition;

//     position.setZ(i, position.getZ(i) + waveOffset);
//   }

//   position.needsUpdate = true;

//   return (
//     <mesh ref={meshRef} geometry={geometry}>
//       <meshStandardMaterial map={logoTexture} side={THREE.DoubleSide} />
//     </mesh>
//   );
// };

// const Scene = () => {
//   const logoTexture = useLoader(
//     THREE.TextureLoader,
//     "https://t3.ftcdn.net/jpg/05/50/26/54/360_F_550265413_q14RreIwKgEuWEfZ6s6xIgish7SfOZrC.jpg"
//   );

//   return (
//     <Canvas camera={{ position: [0, 0, 10], fov: 60 }}>
//       <ambientLight intensity={0.5} />
//       <directionalLight position={[5, 5, 5]} intensity={1} />
//       <OrbitControls />
//       <InfiniteWavyRing
//         innerRadius={1.5}
//         outerRadius={2}
//         waveHeight={0.5}
//         waveFrequency={1.5}
//         logoTexture={logoTexture}
//       />
//     </Canvas>
//   );
// };

// export default Scene;


// -------------------------------------------------Final Code  ---

import * as THREE from "three";
import { Canvas, useLoader } from "@react-three/fiber";
import { useRef, useMemo } from "react";
import { OrbitControls } from "@react-three/drei";

// Custom function to create a circular path for TubeGeometry
const createCircularPath = (radius) => {
  const curve = new THREE.Curve();
  curve.getPoint = (t) => {
    const angle = t * 2 * Math.PI;
    return new THREE.Vector3(
      Math.cos(angle) * radius,
      Math.sin(angle) * radius,
      0
    );
  };
  return curve;
};

const InfiniteWavyRing = ({
  innerRadius,
  outerRadius,
  waveHeight,
  waveFrequency,
  logoTexture,
}) => {
  const meshRef = useRef();
  const path = useMemo(
    () => createCircularPath((innerRadius + outerRadius) / 2),
    [innerRadius, outerRadius]
  );
  const tubeRadius = (outerRadius - innerRadius) / 2; // Inner thickness of the ring

  // Create TubeGeometry for the main ring
  const geometry = new THREE.TubeGeometry(path, 128, tubeRadius, 32, true);
  const position = geometry.attributes.position;

  // Apply wave effect to the main ring geometry
  for (let i = 0; i < position.count; i++) {
    const x = position.getX(i);
    const y = position.getY(i);

    const waveFactor = Math.sin((y + x) * waveFrequency);
    const smoothTransition = Math.cos(
      ((Math.abs(y) % (2 * Math.PI)) / (2 * Math.PI)) * Math.PI
    );
    const waveOffset = waveFactor * waveHeight * smoothTransition;

    position.setZ(i, position.getZ(i) + waveOffset);
  }

  position.needsUpdate = true;

  // Create an inner line path along the ring’s inner thickness center
  const innerLineGeometry = new THREE.TubeGeometry(
    path,
    128,
    tubeRadius * 0.05,
    8,
    true
  ); // Inner line with a very thin radius

  return (
    <>
      {/* Main Ring with Texture */}
      <mesh ref={meshRef} geometry={geometry}>
        <meshStandardMaterial map={logoTexture} side={THREE.DoubleSide} />
      </mesh>
      {/* Orange Line along the inner surface */}
      <mesh geometry={innerLineGeometry}>
        <meshBasicMaterial color="orange" />
      </mesh>
    </>
  );
};

const Scene = () => {
  const logoTexture = useLoader(
    THREE.TextureLoader,
    "https://t3.ftcdn.net/jpg/05/50/26/54/360_F_550265413_q14RreIwKgEuWEfZ6s6xIgish7SfOZrC.jpg" // Local logo texture path
  );

  return (
    <Canvas camera={{ position: [0, 0, 10], fov: 60 }}>
      <ambientLight intensity={0.5} />
      <directionalLight position={[5, 5, 5]} intensity={1} />
      <OrbitControls />
      <InfiniteWavyRing
        innerRadius={1.5}
        outerRadius={2}
        waveHeight={0.5}
        waveFrequency={1.5}
        logoTexture={logoTexture}
      />
    </Canvas>
  );
};

export default Scene;
